// src/hooks/useEditorStore.ts
import { create } from "zustand";

/* --------------------------------------------------------- */
/* Types                                                     */
/* --------------------------------------------------------- */
export type FeatureOption = {
  id: string;
  label: string;
  highlighted?: boolean;  // istaknuta "pill" opcija u boji paketa
};

export type Extra = {
  id: string;
  text: string;
  price?: number;
  selected?: boolean;
};

export type RangePricing =
  | { mode: "linear"; deltaPerUnit: number }
  | { mode: "per-step"; perStep: number[] };

export type OptionGroup = {
  id: string;
  title: string;
  type: "features" | "range" | "options";
  // features
  pkgId?: string;
  options?: FeatureOption[]; // koristi se za type === "features" | "options"
  // range
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  base?: number;
  pricing?: RangePricing;
  // visual
  color?: string;
};

export type Pkg = {
  id: string;
  label: string;
  basePrice: number | null;
  description?: string;
  featured?: boolean;
  color?: string;
};

export type CalcMeta = {
  id?: string;
  name?: string;
  slug?: string;
  [k: string]: unknown;
};

export type CalcJson = {
  meta: CalcMeta;
  packages: Pkg[];
  fields: OptionGroup[]; // features (po paketu) + range (global)
  addons: Extra[];       // global extras
  i18n?: { currency?: string; decimals?: number; [k: string]: unknown };
  [k: string]: unknown;
};

/* --------------------------------------------------------- */
/* Helpers                                                   */
/* --------------------------------------------------------- */
function genId(prefix = "id"): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 8)}${Date.now()
    .toString(36)
    .slice(-4)}`;
}
function deepClone<T>(v: T): T {
  return (globalThis as any).structuredClone
    ? (structuredClone as any)(v)
    : JSON.parse(JSON.stringify(v));
}
function ensureShape(calc: CalcJson): CalcJson {
  if (!Array.isArray(calc.packages)) calc.packages = [];
  if (!Array.isArray(calc.fields)) calc.fields = [];
  if (!Array.isArray(calc.addons)) calc.addons = [];
  // norm fields
  calc.fields = calc.fields.map((g: any) => {
    const type: OptionGroup["type"] =
      g?.type === "range" || g?.type === "options" || g?.type === "features"
        ? g.type
        : "options";
    const base: OptionGroup = {
      id: g.id ?? genId("grp"),
      title: g.title ?? (type === "range" ? "Range" : "Group"),
      type,
    };
    if (type === "features") {
      base.pkgId = g.pkgId;
      base.options = Array.isArray(g.options) ? g.options : [];
    } else if (type === "range") {
      base.min = Number.isFinite(g.min) ? g.min : 0;
      base.max = Number.isFinite(g.max) ? g.max : 10;
      base.step = Number.isFinite(g.step) ? g.step : 1;
      base.unit = g.unit ?? "";
      base.base = Number.isFinite(g.base) ? g.base : 0;
      base.pricing =
        g.pricing && g.pricing.mode === "per-step"
          ? { mode: "per-step", perStep: Array.isArray(g.pricing.perStep) ? g.pricing.perStep : [] }
          : { mode: "linear", deltaPerUnit: Number(g?.pricing?.deltaPerUnit ?? 0) };
    } else {
      base.options = Array.isArray(g.options) ? g.options : [];
    }
    if (g.color) base.color = g.color;
    return base;
  });
  return calc;
}

/* --------------------------------------------------------- */
/* Store                                                     */
/* --------------------------------------------------------- */
type EditorState = {
  slug: string;
  calc: CalcJson | null;

  isDirty: boolean;
  isSaving: boolean;
  lastSaved: number | null;

  maxPackages: number;

  lastWarn?: string;
  lastError?: string;

  init: (slug: string, initialCalc: CalcJson) => void;
  setCalc: (next: CalcJson) => void;
  updateCalc: (fn: (draft: CalcJson) => void) => void;

  // Packages
  addPackage: (partial?: Partial<Pkg>) => string | void;
  updatePackage: (id: string, patch: Partial<Pkg>) => void;
  removePackage: (id: string) => void;

  // Features (per package) - čuva se u fields kao type:"features"
  ensureFeatureGroup: (pkgId: string) => string; // kreira ako ne postoji, vraća groupId
  addFeature: (pkgId: string, label?: string) => string | void;
  updateFeature: (pkgId: string, featId: string, patch: Partial<FeatureOption>) => void;
  removeFeature: (pkgId: string, featId: string) => void;

  // Global Extras (addons)
  addExtra: (text?: string) => string;
  updateExtra: (id: string, patch: Partial<Extra>) => void;
  removeExtra: (id: string) => void;

  // Global Ranges (fields type:"range")
  addRangeGroup: (title?: string) => string;
  updateRangeGroup: (id: string, patch: Partial<OptionGroup>) => void;
  removeRangeGroup: (id: string) => void;

  // Limits / utils
  setMaxPackages: (n: number) => void;
  setPlanCaps: (plan: string) => void;

  setWarn: (msg?: string) => void;
  setError: (msg?: string) => void;
};

export const useEditorStore = create<EditorState>((set, get) => ({
  slug: "",
  calc: null,

  isDirty: false,
  isSaving: false,
  lastSaved: null,

  maxPackages: 6,

  lastWarn: undefined,
  lastError: undefined,

  init: (slug, initialCalc) => {
    const safe = ensureShape(deepClone(initialCalc));
    set({
      slug,
      calc: safe,
      isDirty: false,
      isSaving: false,
      lastSaved: null,
      lastWarn: undefined,
      lastError: undefined,
    });
  },

  setCalc: (next) => {
    const safe = ensureShape(deepClone(next));
    set({ calc: safe, isDirty: false, lastError: undefined, lastWarn: undefined });
  },

  updateCalc: (fn) => {
    const current = get().calc;
    if (!current) return;
    const draft = ensureShape(deepClone(current));
    fn(draft);
    set({ calc: ensureShape(draft), isDirty: true });
  },

  /* ------------------ Packages ------------------ */
  addPackage: (partial) => {
    const st = get();
    const calc = st.calc;
    if (!calc) return;
    if (calc.packages.length >= st.maxPackages) {
      set({ lastWarn: `Package limit reached: ${st.maxPackages}. Upgrade plan to add more.` });
      return;
    }
    const id = genId("pkg");
    const pkg: Pkg = {
      id,
      label: partial?.label ?? `Package ${calc.packages.length + 1}`,
      basePrice: partial?.basePrice ?? 0,
      description: partial?.description ?? "",
      featured: partial?.featured ?? false,
      color: partial?.color,
    };
    const next = deepClone(calc);
    next.packages.push(pkg);
    set({ calc: next, isDirty: true, lastWarn: undefined });
    return id;
  },

  updatePackage: (id, patch) => {
    const st = get();
    const calc = st.calc;
    if (!calc) return;
    const next = deepClone(calc);
    next.packages = next.packages.map((p) => (p.id === id ? { ...p, ...patch } : p));
    set({ calc: next, isDirty: true });
  },

  removePackage: (id) => {
    const st = get();
    const calc = st.calc;
    if (!calc) return;
    const next = deepClone(calc);
    next.packages = next.packages.filter((p) => p.id !== id);
    // ukloni i feature grupe vezane za ovaj paket
    next.fields = next.fields.filter((g) => !(g.type === "features" && g.pkgId === id));
    set({ calc: next, isDirty: true });
  },

  /* ------------------ Features (fields type:"features") ------------------ */
  ensureFeatureGroup: (pkgId) => {
    const st = get(); const calc = st.calc!;
    const existing = calc.fields.find((g) => g.type === "features" && g.pkgId === pkgId);
    if (existing) return existing.id;
    const id = genId("feat");
    const next = deepClone(calc);
    next.fields.push({ id, title: "Features", type: "features", pkgId, options: [] });
    set({ calc: next, isDirty: true });
    return id;
  },

  addFeature: (pkgId, label) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    let grp = next.fields.find((g) => g.type === "features" && g.pkgId === pkgId);
    if (!grp) {
      grp = { id: genId("feat"), title: "Features", type: "features", pkgId, options: [] };
      next.fields.push(grp);
    }
    const id = genId("f");
    (grp.options as FeatureOption[]).push({ id, label: label ?? "New feature", highlighted: false });
    set({ calc: next, isDirty: true });
    return id;
  },

  updateFeature: (pkgId, featId, patch) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    const grp = next.fields.find((g) => g.type === "features" && g.pkgId === pkgId);
    if (!grp || !grp.options) return;
    grp.options = (grp.options as FeatureOption[]).map((f) => (f.id === featId ? { ...f, ...patch } : f));
    set({ calc: next, isDirty: true });
  },

  removeFeature: (pkgId, featId) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    const grp = next.fields.find((g) => g.type === "features" && g.pkgId === pkgId);
    if (!grp || !grp.options) return;
    grp.options = (grp.options as FeatureOption[]).filter((f) => f.id !== featId);
    set({ calc: next, isDirty: true });
  },

  /* ------------------ Global Extras ------------------ */
  addExtra: (text) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    const id = genId("x");
    next.addons.push({ id, text: text ?? "New extra", price: 0, selected: false });
    set({ calc: next, isDirty: true });
    return id;
  },

  updateExtra: (id, patch) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    next.addons = next.addons.map((x) => (x.id === id ? { ...x, ...patch } : x));
    set({ calc: next, isDirty: true });
  },

  removeExtra: (id) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    next.addons = next.addons.filter((x) => x.id !== id);
    set({ calc: next, isDirty: true });
  },

  /* ------------------ Global Range groups ------------------ */
  addRangeGroup: (title) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    const id = genId("rng");
    next.fields.push({
      id,
      title: title ?? "Range",
      type: "range",
      min: 0, max: 10, step: 1, base: 0, unit: "",
      pricing: { mode: "linear", deltaPerUnit: 0 },
    });
    set({ calc: next, isDirty: true });
    return id;
  },

  updateRangeGroup: (id, patch) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    next.fields = next.fields.map((g) => (g.id === id ? { ...g, ...patch } : g));
    set({ calc: next, isDirty: true });
  },

  removeRangeGroup: (id) => {
    const st = get(); const calc = st.calc!;
    const next = deepClone(calc);
    next.fields = next.fields.filter((g) => g.id !== id);
    set({ calc: next, isDirty: true });
  },

  /* ------------------ Limits / utils ------------------ */
  setMaxPackages: (n) => set({ maxPackages: Math.max(0, n) }),
  setPlanCaps: (plan) => {
    const map: Record<string, number> = { free: 1, starter: 3, growth: 5, pro: 8, tierless: 12 };
    const n = map[plan] ?? 6;
    set({ maxPackages: n });
  },

  setWarn: (msg) => set({ lastWarn: msg }),
  setError: (msg) => set({ lastError: msg }),
}));
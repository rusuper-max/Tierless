// src/app/editor/[id]/panels/BlocksPanel.tsx
"use client";

import {
  useEditorStore,
  type Pkg,
  type FeatureOption,
  type OptionGroup,
  type RangePricing,
} from "@/hooks/useEditorStore";

/* --------------------------------------------------------- */
/* Local type guards for union narrowing                     */
/* --------------------------------------------------------- */
export type RangeGroup = OptionGroup & {
  type: "range";
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  base?: number;
  pricing?: RangePricing;
};

export type FeaturesGroup = OptionGroup & {
  type: "features";
  pkgId?: string;
  options?: FeatureOption[];
};

function isRange(g: OptionGroup): g is RangeGroup {
  return g.type === "range";
}
function isFeatures(g: OptionGroup): g is FeaturesGroup {
  return g.type === "features";
}

/* ========================================================= */
/* Main                                                      */
/* ========================================================= */
export default function BlocksPanel() {
  const calc             = useEditorStore((s) => s.calc);
  const lastWarn         = useEditorStore((s) => s.lastWarn);

  const maxPackages      = useEditorStore((s) => s.maxPackages);
  const setMaxPackages   = useEditorStore((s) => s.setMaxPackages);

  // Packages
  const addPackage       = useEditorStore((s) => s.addPackage);
  const updatePackage    = useEditorStore((s) => s.updatePackage);
  const removePackage    = useEditorStore((s) => s.removePackage);

  // Features (per package; stored in fields)
  const ensureFeatureGrp = useEditorStore((s) => s.ensureFeatureGroup);
  const addFeature       = useEditorStore((s) => s.addFeature);
  const updateFeature    = useEditorStore((s) => s.updateFeature);
  const removeFeature    = useEditorStore((s) => s.removeFeature);

  // Global Extras (addons)
  const addExtra         = useEditorStore((s) => s.addExtra);
  const updateExtra      = useEditorStore((s) => s.updateExtra);
  const removeExtra      = useEditorStore((s) => s.removeExtra);

  // Global Ranges (fields type:"range")
  const addRangeGroup    = useEditorStore((s) => s.addRangeGroup);
  const updateRangeGroup = useEditorStore((s) => s.updateRangeGroup);
  const removeRangeGroup = useEditorStore((s) => s.removeRangeGroup);

  // Narrow null/undefined early
  if (!calc) return <div className="text-sm opacity-70">No calc loaded.</div>;

  // From here on, work with narrowed, non-null locals (so TS stops whining)
  const packages: Pkg[] = Array.isArray(calc.packages) ? calc.packages : [];
  const fields: OptionGroup[] = Array.isArray(calc.fields) ? calc.fields : [];
  const addons = Array.isArray(calc.addons) ? calc.addons : [];

  const pkgCount = packages.length;
  const canAdd   = pkgCount < maxPackages;

  // helpers (no closure over possibly-null `calc`)
  function featuresFor(pkgId: string, srcFields: OptionGroup[]): FeatureOption[] {
    const g = srcFields.find((f): f is FeaturesGroup => isFeatures(f) && f.pkgId === pkgId);
    return g?.options ?? [];
  }

  const rangeGroups: RangeGroup[] = fields.filter(isRange);

  return (
    <div className="space-y-10">
      {lastWarn && (
        <div className="rounded-lg border border-amber-500/40 bg-amber-500/10 p-3 text-sm">
          {lastWarn}
        </div>
      )}

      {/* ------------------ Packages + Features ------------------ */}
      <section className="space-y-6">
        <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
          <h3 className="text-base font-medium">Packages</h3>
          <div className="flex items-center gap-2">
            <span className="text-xs opacity-70">{pkgCount}/{maxPackages}</span>
            <button
              type="button"
              className={`rounded-lg border px-3 py-1.5 text-sm ${!canAdd ? "opacity-50 cursor-not-allowed" : ""}`}
              onClick={() => canAdd && addPackage({ label: `Package ${pkgCount + 1}`, basePrice: 0 })}
              disabled={!canAdd}
            >
              + Add package
            </button>
          </div>
        </div>

        {pkgCount === 0 ? (
          <p className="text-sm opacity-70">No packages yet.</p>
        ) : (
          <div className="space-y-4">
            {packages.map((p) => (
              <PackageCard
                key={p.id}
                pkg={p}
                features={featuresFor(p.id, fields)}
                onPkgChange={(patch) => updatePackage(p.id, patch)}
                onPkgRemove={() => removePackage(p.id)}
                onEnsureFeatures={() => ensureFeatureGrp(p.id)}
                onAddFeature={() => addFeature(p.id, "New feature")}
                onFeatureChange={(fid, patch) => updateFeature(p.id, fid, patch)}
                onFeatureRemove={(fid) => removeFeature(p.id, fid)}
              />
            ))}
          </div>
        )}

        <div className="mt-2 flex items-center gap-2 text-xs opacity-70">
          <span>Temp cap:</span>
          <input
            type="number"
            className="w-16 rounded border bg-transparent px-2 py-1"
            value={maxPackages}
            onChange={(e) => setMaxPackages(Math.max(0, Number(e.target.value || 0)))}
          />
        </div>
      </section>

      {/* ------------------ Global Extras ------------------ */}
      <section>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-base font-medium">Extras (global)</h3>
          <button
            type="button"
            className="rounded-lg border px-3 py-1.5 text-sm"
            onClick={() => addExtra("New extra")}
          >
            + Add extra
          </button>
        </div>

        {addons.length === 0 ? (
          <p className="text-sm opacity-70">No extras.</p>
        ) : (
          <div className="space-y-2">
            {addons.map((x) => (
              <div key={x.id} className="flex flex-wrap items-center gap-2">
                <input
                  className="min-w-0 flex-1 rounded border bg-transparent px-2 py-1 text-sm"
                  value={x.text}
                  onChange={(e) => updateExtra(x.id, { text: e.target.value })}
                />
                <input
                  type="number"
                  className="w-24 rounded border bg-transparent px-2 py-1 text-sm"
                  value={Number(x.price ?? 0)}
                  onChange={(e) => updateExtra(x.id, { price: Number(e.target.value || 0) })}
                  title="Price"
                />
                <label className="flex items-center gap-1 text-xs">
                  <input
                    type="checkbox"
                    checked={!!x.selected}
                    onChange={(e) => updateExtra(x.id, { selected: e.target.checked })}
                  />
                  default
                </label>
                <button
                  type="button"
                  className="rounded-lg border border-red-500/60 px-3 py-1.5 text-sm text-red-500"
                  onClick={() => removeExtra(x.id)}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}
      </section>

      {/* ------------------ Global Sliders ------------------ */}
      <section>
        <div className="mb-2 flex items-center justify-between">
          <h3 className="text-base font-medium">Sliders (global)</h3>
          <button
            type="button"
            className="rounded-lg border px-3 py-1.5 text-sm"
            onClick={() => addRangeGroup("Range")}
          >
            + Add slider
          </button>
        </div>

        {rangeGroups.length === 0 ? (
          <p className="text-sm opacity-70">No sliders.</p>
        ) : (
          <div className="space-y-3">
            {rangeGroups.map((g) => (
              <RangeCard
                key={g.id}
                group={g}
                onChange={(patch) => updateRangeGroup(g.id, patch)}
                onRemove={() => removeRangeGroup(g.id)}
              />
            ))}
          </div>
        )}
      </section>
    </div>
  );
}

/* ========================================================= */
/* Packages + Features                                       */
/* ========================================================= */
function PackageCard(props: {
  pkg: Pkg;
  features: FeatureOption[];
  onPkgChange: (patch: Partial<Pkg>) => void;
  onPkgRemove: () => void;

  onEnsureFeatures: () => void;
  onAddFeature: () => void;
  onFeatureChange: (fid: string, patch: Partial<FeatureOption>) => void;
  onFeatureRemove: (fid: string) => void;
}) {
  const {
    pkg, features, onPkgChange, onPkgRemove,
    onEnsureFeatures, onAddFeature, onFeatureChange, onFeatureRemove,
  } = props;

  return (
    <div className="rounded-xl border p-4">
      <div className="mb-2 flex items-center justify-between">
        <div className="font-medium">{pkg.label || "Package"}</div>
        <button
          type="button"
          className="rounded-lg border border-red-500/60 px-3 py-1.5 text-sm text-red-500"
          onClick={onPkgRemove}
        >
          Remove
        </button>
      </div>

      <div className="grid gap-2 sm:grid-cols-2">
        <Field label="Label">
          <input
            className="w-full rounded border bg-transparent px-2 py-1"
            value={pkg.label}
            onChange={(e) => onPkgChange({ label: e.target.value })}
          />
        </Field>
        <Field label="Base price">
          <input
            type="number"
            className="w-full rounded border bg-transparent px-2 py-1"
            value={pkg.basePrice ?? 0}
            onChange={(e) => onPkgChange({ basePrice: Number(e.target.value || 0) })}
          />
        </Field>
        <Field label="Featured">
          <div className="flex items-center gap-2">
            <input
              id={`feat_${pkg.id}`}
              type="checkbox"
              checked={!!pkg.featured}
              onChange={(e) => onPkgChange({ featured: e.target.checked })}
            />
            <label htmlFor={`feat_${pkg.id}`} className="text-sm">Highlight card</label>
          </div>
        </Field>
        <Field label="Tier color">
          <input
            className="w-full rounded border bg-transparent px-2 py-1"
            placeholder="#22D3EE"
            value={pkg.color ?? ""}
            onChange={(e) => onPkgChange({ color: e.target.value })}
          />
        </Field>
      </div>
      <Field label="Description">
        <textarea
          className="w-full rounded border bg-transparent px-2 py-1"
          rows={2}
          value={pkg.description ?? ""}
          onChange={(e) => onPkgChange({ description: e.target.value })}
        />
      </Field>

      {/* Features */}
      <div className="mt-4">
        <div className="mb-2 flex items-center justify-between">
          <div className="font-medium">Features</div>
          <div className="flex items-center gap-2">
            <button
              type="button"
              className="rounded-lg border px-3 py-1.5 text-sm"
              onClick={onEnsureFeatures}
              title="Ensure feature group exists"
            >
              Ensure
            </button>
            <button
              type="button"
              className="rounded-lg border px-3 py-1.5 text-sm"
              onClick={onAddFeature}
            >
              + Add feature
            </button>
          </div>
        </div>

        {features.length === 0 ? (
          <p className="text-sm opacity-70">No features.</p>
        ) : (
          <div className="space-y-2">
            {features.map((f) => (
              <div key={f.id} className="flex flex-wrap items-center gap-2">
                <input
                  className="min-w-0 flex-1 rounded border bg-transparent px-2 py-1 text-sm"
                  value={f.label}
                  onChange={(e) => onFeatureChange(f.id, { label: e.target.value })}
                />
                <label className="flex items-center gap-1 text-xs">
                  <input
                    type="checkbox"
                    checked={!!f.highlighted}
                    onChange={(e) => onFeatureChange(f.id, { highlighted: e.target.checked })}
                  />
                  highlighted
                </label>
                <button
                  type="button"
                  className="rounded-lg border border-red-500/60 px-3 py-1.5 text-sm text-red-500"
                  onClick={() => onFeatureRemove(f.id)}
                >
                  Remove
                </button>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

/* ========================================================= */
/* Global Range groups                                       */
/* ========================================================= */
function RangeCard({
  group,
  onChange,
  onRemove,
}: {
  group: RangeGroup;
  onChange: (patch: Partial<RangeGroup>) => void;
  onRemove: () => void;
}) {
  const min = Number.isFinite(group.min) ? (group.min as number) : 0;
  const max = Number.isFinite(group.max) ? (group.max as number) : 10;
  const step = Number.isFinite(group.step) ? (group.step as number) : 1;
  const segCount = Math.max(0, Math.floor((max - min) / Math.max(1, step)));

  function perStepEnsure(cur?: number[]) {
    const arr = Array.isArray(cur) ? [...cur] : [];
    if (arr.length !== segCount) {
      if (arr.length < segCount) while (arr.length < segCount) arr.push(0);
      else arr.length = segCount;
    }
    return arr;
  }

  const pricing = group.pricing?.mode
    ? group.pricing
    : ({ mode: "linear", deltaPerUnit: 0 } as RangePricing);

  return (
    <div className="rounded-xl border p-3">
      <div className="mb-2 flex items-center justify-between">
        <input
          className="min-w-0 flex-1 rounded border bg-transparent px-2 py-1 text-sm"
          value={group.title}
          onChange={(e) => onChange({ title: e.target.value })}
        />
        <button
          type="button"
          className="ml-2 rounded-lg border border-red-500/60 px-3 py-1.5 text-sm text-red-500"
          onClick={onRemove}
        >
          Remove
        </button>
      </div>

      <div className="grid gap-2 sm:grid-cols-5">
        <Field label="Min">
          <input
            type="number"
            className="w-full rounded border bg-transparent px-2 py-1"
            value={min}
            onChange={(e) => onChange({ min: Number(e.target.value || 0) })}
          />
        </Field>
        <Field label="Max">
          <input
            type="number"
            className="w-full rounded border bg-transparent px-2 py-1"
            value={max}
            onChange={(e) => onChange({ max: Number(e.target.value || 0) })}
          />
        </Field>
        <Field label="Step">
          <input
            type="number"
            className="w-full rounded border bg-transparent px-2 py-1"
            value={step}
            onChange={(e) => onChange({ step: Number(e.target.value || 1) })}
          />
        </Field>
        <Field label="Unit">
          <input
            className="w-full rounded border bg-transparent px-2 py-1"
            value={group.unit ?? ""}
            onChange={(e) => onChange({ unit: e.target.value })}
          />
        </Field>
        <Field label="Base">
          <input
            type="number"
            className="w-full rounded border bg-transparent px-2 py-1"
            value={Number(group.base ?? 0)}
            onChange={(e) => onChange({ base: Number(e.target.value || 0) })}
          />
        </Field>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-3 text-sm">
        <span className="opacity-70">Pricing mode:</span>
        <label className="flex items-center gap-1">
          <input
            type="radio"
            name={`pr_${group.id}`}
            checked={pricing.mode === "linear"}
            onChange={() => onChange({ pricing: { mode: "linear", deltaPerUnit: 0 } })}
          />
          Linear
        </label>
        <label className="flex items-center gap-1">
          <input
            type="radio"
            name={`pr_${group.id}`}
            checked={pricing.mode === "per-step"}
            onChange={() =>
              onChange({
                pricing: {
                  mode: "per-step",
                  perStep: perStepEnsure((pricing as any).perStep),
                },
              })
            }
          />
          Per-step
        </label>
      </div>

      {pricing.mode === "linear" ? (
        <div className="mt-2 max-w-xs">
          <Field label="Δ per unit">
            <input
              type="number"
              className="w-full rounded border bg-transparent px-2 py-1"
              value={(pricing as any).deltaPerUnit ?? 0}
              onChange={(e) =>
                onChange({ pricing: { mode: "linear", deltaPerUnit: Number(e.target.value || 0) } })
              }
            />
          </Field>
          <p className="mt-1 text-xs opacity-70">Total delta = (value - base) × Δ per unit</p>
        </div>
      ) : (
        <div className="mt-2">
          <div className="mb-1 text-xs opacity-70">Segments: {segCount}</div>
          <div className="grid grid-cols-2 gap-2 sm:grid-cols-4 md:grid-cols-6">
            {perStepEnsure((pricing as any).perStep).map((val, i) => (
              <Field key={i} label={`S${i + 1}`}>
                <input
                  type="number"
                  className="w-full rounded border bg-transparent px-2 py-1"
                  value={val}
                  onChange={(e) => {
                    const arr = perStepEnsure((pricing as any).perStep);
                    arr[i] = Number(e.target.value || 0);
                    onChange({ pricing: { mode: "per-step", perStep: arr } });
                  }}
                />
              </Field>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

/* ========================================================= */
/* Small UI helpers                                          */
/* ========================================================= */
function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block text-sm">
      <span className="mb-1 block opacity-70">{label}</span>
      {children}
    </label>
  );
}
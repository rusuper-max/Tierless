// src/app/editor/[id]/panels/MetaPanel.tsx
"use client";

import { useCallback, useState, useEffect } from "react";
import { useEditorStore } from "@/hooks/useEditorStore";
import { t } from "@/i18n";

/* ------------------------------------------------------------------ */
/* MetaPanel                                                           */
/* ------------------------------------------------------------------ */

export default function MetaPanel() {
  const calc = useEditorStore((s) => s.calc);
  const updateMeta = useEditorStore((s) => s.updateMeta);
  const setSlug = useEditorStore((s) => s.setSlug); // ako postoji u store-u

  const [name, setName] = useState(calc?.meta?.name ?? "");
  const [slug, setSlugLocal] = useState(calc?.meta?.slug ?? "");
  const [desc, setDesc] = useState(calc?.meta?.description ?? "");

  // sync local state kad se zameni trenutni calc (npr. LOAD)
  useEffect(() => {
    setName(calc?.meta?.name ?? "");
    setSlugLocal(calc?.meta?.slug ?? "");
    setDesc(calc?.meta?.description ?? "");
  }, [calc?.meta?.name, calc?.meta?.slug, calc?.meta?.description]);

  const commitName = useCallback(
    (v: string) => {
      updateMeta({ name: v });
    },
    [updateMeta]
  );

  const commitSlug = useCallback(
    (v: string) => {
      // minimal slugify — backend će svakako normalizovati
      const next = v.trim().toLowerCase().replace(/\s+/g, "-").replace(/[^a-z0-9-_]/g, "");
      updateMeta({ slug: next });
      // ako store ima setSlug, ažuriraj i URL state za editor
      try {
        setSlug?.(next);
      } catch {}
    },
    [updateMeta, setSlug]
  );

  const commitDesc = useCallback(
    (v: string) => {
      updateMeta({ description: v });
    },
    [updateMeta]
  );

  return (
    <div className="space-y-4">
      <Field label={t("Name")}>
        <input
          className="w-full rounded-md bg-transparent px-2 py-1 text-sm outline outline-1 outline-[color-mix(in_oklab,var(--border,#2B2D31)_60%,transparent)]"
          value={name}
          onChange={(e) => setName(e.target.value)}
          onBlur={(e) => commitName(e.target.value)}
          placeholder={t("My price page")}
        />
      </Field>

      <Field label={t("Slug")}>
        <input
          className="w-full rounded-md bg-transparent px-2 py-1 text-sm outline outline-1 outline-[color-mix(in_oklab,var(--border,#2B2D31)_60%,transparent)]"
          value={slug}
          onChange={(e) => setSlugLocal(e.target.value)}
          onBlur={(e) => commitSlug(e.target.value)}
          placeholder="my-price-page"
        />
        <p className="mt-1 text-2xs text-[var(--muted,#9aa0a6)]">
          {t("Public URL")}:
          <span className="ml-1 opacity-80">/start/{slug || t("your-slug")}</span>
        </p>
      </Field>

      <Field label={t("Description")}>
        <textarea
          rows={3}
          className="w-full rounded-md bg-transparent px-2 py-1 text-sm outline outline-1 outline-[color-mix(in_oklab,var(--border,#2B2D31)_60%,transparent)]"
          value={desc}
          onChange={(e) => setDesc(e.target.value)}
          onBlur={(e) => commitDesc(e.target.value)}
          placeholder={t("Short summary of this page")}
        />
      </Field>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/* UI                                                                  */
/* ------------------------------------------------------------------ */

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="block">
      <div className="mb-1 text-xs uppercase tracking-wide text-[var(--muted,#9aa0a6)]">{label}</div>
      {children}
    </label>
  );
}
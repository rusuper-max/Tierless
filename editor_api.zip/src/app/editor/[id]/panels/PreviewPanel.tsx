// src/app/editor/[id]/panels/PreviewPanel.tsx
"use client";

import { useMemo } from "react";
import { useEditorStore } from "@/hooks/useEditorStore";
import RenderRoot from "@/lib/editor/renderer/RenderRoot";
import { t } from "@/i18n";

/* ------------------------------------------------------------------ */
/* PreviewPanel                                                        */
/* ------------------------------------------------------------------ */

export default function PreviewPanel({ embedded = false }: { embedded?: boolean }) {
  const calc = useEditorStore((s) => s.calc);

  const boxCls = embedded
    ? "rounded-xl border border-[color-mix(in_oklab,var(--border,#2B2D31)_60%,transparent)] p-3"
    : "";

  const header = useMemo(
    () => (
      <div className="mb-2 flex items-center justify-between">
        <div className="text-xs uppercase tracking-wide text-[var(--muted,#9aa0a6)]">{t("Preview (live)")}</div>
        <a
          href="/dashboard"
          className="text-2xs opacity-80 hover:opacity-100 underline-offset-2 hover:underline"
        >
          ← {t("Back to Dashboard")}
        </a>
      </div>
    ),
    []
  );

  return (
    <div className={boxCls}>
      {header}
      <div className="rounded-lg border border-[color-mix(in_oklab,var(--border,#2B2D31)_60%,transparent)] p-3">
        <div className="mx-auto max-w-2xl">
          <RenderRoot calc={calc} mode="editor" />
        </div>
      </div>
    </div>
  );
}
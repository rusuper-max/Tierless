// src/app/editor/[id]/panels/PackagesPanel.tsx
"use client";

import { useMemo, useState } from "react";
import { useEditorStore } from "@/hooks/useEditorStore";

type Pkg = {
  id: string;
  label: string;
  basePrice: number | null;
  featured?: boolean;
  description?: string;
  color?: string;
};

function newPkg(): Pkg {
  return {
    id: `pkg_${Math.random().toString(36).slice(2, 8)}`,
    label: "New plan",
    basePrice: 0,
    featured: false,
    description: "",
    color: "#475569", // default siva
  };
}

export default function PackagesPanel() {
  const calc = useEditorStore((s) => s.calc);
  const updateCalc = useEditorStore((s) => s.updateCalc);

  const pkgs = useMemo<Pkg[]>(
    () => (Array.isArray(calc?.packages) ? (calc!.packages as Pkg[]) : []),
    [calc?.packages]
  );

  function setPkgs(next: Pkg[]) {
    // Single source of truth: upisujemo u calc.packages
    updateCalc((prev: any) => ({ ...(prev || {}), packages: next }));
  }

  function addOne() {
    setPkgs([...(pkgs || []), newPkg()]);
  }

  function removeOne(id: string) {
    setPkgs((pkgs || []).filter((p) => p.id !== id));
  }

  function updateOne(id: string, patch: Partial<Pkg>) {
    setPkgs((pkgs || []).map((p) => (p.id === id ? { ...p, ...patch } : p)));
  }

  function move(id: string, dir: -1 | 1) {
    const list = [...(pkgs || [])];
    const i = list.findIndex((p) => p.id === id);
    if (i < 0) return;
    const j = Math.max(0, Math.min(list.length - 1, i + dir));
    if (i === j) return;
    const [el] = list.splice(i, 1);
    list.splice(j, 0, el);
    setPkgs(list);
  }

  function seedDemo() {
    setPkgs([
      { id: "basic", label: "Basic", basePrice: 149, featured: true, description: "Email inquiries\n1 page link", color: "#0ea5e9" },
      { id: "standard", label: "Standard", basePrice: 299, featured: false, description: "Brand colors\nAnalytics lite", color: "#22c55e" },
      { id: "business", label: "Business", basePrice: null, featured: false, description: "Fair use traffic\nAdvanced formulas", color: "#a855f7" },
    ]);
  }

  return (
    <section className="rounded-xl border border-[color-mix(in_oklab,var(--border,#2B2D31)_60%,transparent)] p-4">
      <div className="mb-3 flex items-center justify-between">
        <div className="text-xs uppercase tracking-wide text-[var(--muted,#9aa0a6)]">
          Packages — {pkgs.length}
        </div>
        <div className="flex items-center gap-2">
          <button className="rounded-md border px-2 py-1 text-xs" onClick={seedDemo}>Seed demo</button>
          <button className="rounded-md border px-2 py-1 text-xs" onClick={addOne}>+ Add package</button>
        </div>
      </div>

      {pkgs.length === 0 ? (
        <p className="text-sm opacity-70">No packages yet. Add your first package.</p>
      ) : (
        <ul className="space-y-2">
          {pkgs.map((p, idx) => (
            <li key={p.id} className="rounded-lg border px-3 py-2">
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-3">
                  <input
                    type="color"
                    value={p.color || "#475569"}
                    onChange={(e) => updateOne(p.id, { color: e.target.value })}
                    className="h-6 w-6 cursor-pointer rounded border"
                    title="Card color"
                  />
                  <input
                    className="w-40 rounded border bg-transparent px-2 py-1 text-sm"
                    value={p.label}
                    onChange={(e) => updateOne(p.id, { label: e.target.value })}
                  />
                  <input
                    className="w-24 rounded border bg-transparent px-2 py-1 text-sm"
                    type="number"
                    placeholder="price"
                    value={p.basePrice === null ? "" : String(p.basePrice)}
                    onChange={(e) =>
                      updateOne(p.id, { basePrice: e.target.value === "" ? null : Number(e.target.value) })
                    }
                  />
                  <label className="flex items-center gap-1 text-xs opacity-80">
                    <input
                      type="checkbox"
                      checked={!!p.featured}
                      onChange={(e) => updateOne(p.id, { featured: e.target.checked })}
                    />
                    featured
                  </label>
                </div>

                <div className="flex items-center gap-1">
                  <button className="rounded border px-2 py-1 text-xs" onClick={() => move(p.id, -1)} disabled={idx === 0}>↑</button>
                  <button className="rounded border px-2 py-1 text-xs" onClick={() => move(p.id, +1)} disabled={idx === pkgs.length - 1}>↓</button>
                  <button className="rounded border px-2 py-1 text-xs" onClick={() => removeOne(p.id)}>Delete</button>
                </div>
              </div>

              <textarea
                className="mt-2 w-full rounded border bg-transparent px-2 py-1 text-sm"
                rows={2}
                placeholder="Description (one feature per line)"
                value={p.description || ""}
                onChange={(e) => updateOne(p.id, { description: e.target.value })}
              />
            </li>
          ))}
        </ul>
      )}
    </section>
  );
}
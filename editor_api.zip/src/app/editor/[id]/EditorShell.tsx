// src/app/editor/[id]/EditorShell.tsx
"use client";

import "@/dev/exposeStore"; // (ne smeta u prod; samo za konzolu)
import { useEffect, useMemo, useState } from "react";
import { useEditorStore, type CalcJson } from "@/hooks/useEditorStore";
import { useAutosave } from "@/hooks/useAutosave";
import type { CalcView } from "@/components/PublicRenderer";

// PANELS
import BlocksPanel from "./panels/BlocksPanel";
// Minimalan public prikaz koji čita calc.packages / fields / addons
import PublicRenderer from "@/components/PublicRenderer";

type EditorShellProps = { slug: string; initialCalc: CalcJson };

function isObject(v: unknown): v is Record<string, any> {
  return !!v && typeof v === "object" && !Array.isArray(v);
}
function hasCalcShape(v: any) {
  return isObject(v) && (Array.isArray(v.packages) || Array.isArray(v.fields) || Array.isArray(v.addons));
}

export default function EditorShell({ slug, initialCalc }: EditorShellProps) {
  // ===== Store state
  const init      = useEditorStore(s => s.init);
  const calc      = useEditorStore(s => s.calc);
  const uiSlug    = useEditorStore(s => s.slug);
  const isDirty   = useEditorStore(s => s.isDirty);
  const isSaving  = useEditorStore(s => s.isSaving);
  const lastSaved = useEditorStore(s => s.lastSaved);

  // ===== Boot + autosave
  const [autosaveOn, setAutosaveOn] = useState(true);
  useEffect(() => { init(slug, initialCalc); }, [slug, initialCalc, init]);
  useAutosave(1600, autosaveOn);

  // ===== Public URL
  const publicUrl = useMemo(() => {
    const id = (calc as any)?.meta?.id as string | undefined;
    const s = encodeURIComponent(uiSlug || "");
    return id ? `/p/${id}-${s}` : `/p/${s}`;
  }, [uiSlug, calc]);

  // ===== Save now (force) — robustno protiv “okrnjenog” server responsa
  async function saveNow() {
    const st = useEditorStore.getState();
    const body = st.calc;
    const sl = body?.meta?.slug || st.slug;
    if (!sl || !body) return;

    useEditorStore.setState({ isSaving: true });

    let nextCalc: CalcJson | null = null;
    try {
      const r = await fetch(`/api/calculators/${encodeURIComponent(sl)}`, {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify(body),
        cache: "no-store",
        credentials: "same-origin",
      });

      const j = await r.json().catch(() => ({} as any));
      console.debug("[SAVE PUT] status", r.status, "respKeys:", Object.keys(j || {}));

      const candidate = (j && (j.calc || j)) || null;
      nextCalc = candidate && hasCalcShape(candidate) ? (candidate as CalcJson) : body;
    } catch (e) {
      console.warn("[SAVE PUT] error:", e);
      nextCalc = body; // offline/greška — zadržavamo lokalno
    }

    useEditorStore.setState({
      calc: nextCalc!,
      isDirty: false,
      isSaving: false,
      lastSaved: Date.now(),
    });
  }

  // ===== Publish (save -> POST /api/publish)
  async function publishNow() {
    await saveNow();
    const st = useEditorStore.getState();
    const sl = st?.calc?.meta?.slug || st.slug;
    if (!sl) return;

    const r = await fetch(`/api/publish`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ slug: sl, publish: true }),
      cache: "no-store",
      credentials: "same-origin",
    });
    const j = await r.json().catch(() => ({}));
    console.log("[Publish]", j);
  }

  // ===== Open public (save -> open /p/{id}-{slug})
  async function openPublic() {
    await saveNow();
    const st  = useEditorStore.getState();
    const id  = st?.calc?.meta?.id;
    const s   = encodeURIComponent(st.slug || "");
    const url = id ? `/p/${id}-${s}` : `/p/${s}`;
    window.location.href = url;
  }

  // ===== Adapter ka PublicRenderer: uvek pošalji normalizovan CalcView
  const viewCalc = useMemo<CalcView>(() => ({
    packages: Array.isArray(calc?.packages) ? calc!.packages! : [],
    fields:   Array.isArray(calc?.fields)   ? calc!.fields!   : [],
    addons:   Array.isArray(calc?.addons)   ? calc!.addons!   : [],
  }), [calc]);

  // ===== UI: Tabs (Meta / Blocks / Preview)
  const [active, setActive] = useState<"meta" | "blocks" | "preview">("blocks");
  const pkgCount  = Array.isArray(calc?.packages) ? calc!.packages!.length : 0;
  const optCount  = Array.isArray(calc?.fields)   ? calc!.fields!.length   : 0;
  const extraCnt  = Array.isArray(calc?.addons)   ? calc!.addons!.length   : 0;

  return (
    <main className="min-h-screen p-6">
      <div className="mx-auto max-w-6xl">
        {/* Header */}
        <header className="mb-4 flex items-center justify-between gap-3">
          <div className="min-w-0">
            <div className="truncate text-xl font-semibold">Editor</div>
            <div className="truncate text-sm opacity-70">
              {uiSlug} — {isSaving ? "Saving…" : isDirty ? "Unsaved changes" : lastSaved ? "Saved" : "Loaded"}
            </div>
          </div>

          <div className="flex items-center gap-2">
            <label className="text-sm flex items-center gap-2">
              <input type="checkbox" checked={autosaveOn} onChange={e => setAutosaveOn(e.target.checked)} />
              Autosave
            </label>
            <button className="rounded border px-3 py-1 text-sm" onClick={saveNow} disabled={isSaving}>
              Save now
            </button>
            <button className="rounded border px-3 py-1 text-sm" onClick={publishNow} disabled={isSaving || !calc}>
              Publish
            </button>
            <a className="rounded border px-3 py-1 text-sm" href={publicUrl} onClick={(e) => { e.preventDefault(); openPublic(); }}>
              Open public
            </a>
          </div>
        </header>

        {/* Tabs */}
        <nav className="mb-4 flex flex-wrap items-center gap-2">
          <Tab active={active === "meta"}    onClick={() => setActive("meta")}>Meta</Tab>
          <Tab active={active === "blocks"}  onClick={() => setActive("blocks")}>
            Blocks
            <span className="ml-2 inline-flex items-center rounded bg-neutral-800 px-1.5 py-0.5 text-2xs opacity-80">
              P:{pkgCount} · O:{optCount} · X:{extraCnt}
            </span>
          </Tab>
          <Tab active={active === "preview"} onClick={() => setActive("preview")}>Preview</Tab>
        </nav>

        {/* Panels */}
        <section className="rounded-xl border p-4">
          {active === "meta" && (
            <div className="space-y-3">
              <h2 className="text-lg font-medium">{calc?.meta?.name ?? "Untitled"}</h2>
              <div className="text-sm opacity-70">
                Packages: {pkgCount} · Options groups: {optCount} · Extras: {extraCnt}
              </div>
              <p className="text-sm opacity-70">
                (Ovde može ići tvoj Meta panel — naziv, opis, valuta, brending… Trenutno je placeholder.)
              </p>
            </div>
          )}

          {active === "blocks" && <BlocksPanel />}

          {active === "preview" && (
            <div className="space-y-6">
              <h2 className="text-lg font-medium">{calc?.meta?.name ?? "Preview"}</h2>
              <PublicRenderer calc={viewCalc} />
            </div>
          )}
        </section>
      </div>
    </main>
  );
}

function Tab({
  active,
  onClick,
  children,
}: {
  active: boolean;
  onClick: () => void;
  children: React.ReactNode;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={`rounded-lg border px-3 py-1.5 text-sm transition ${
        active
          ? "border-[color-mix(in_oklab,var(--brand-1,#4F46E5)_70%,transparent)] bg-[color-mix(in_oklab,var(--brand-1,#4F46E5)_10%,transparent)]"
          : "hover:border-[color-mix(in_oklab,var(--brand-1,#4F46E5)_50%,transparent)]"
      }`}
    >
      {children}
    </button>
  );
}
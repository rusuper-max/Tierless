// src/components/PublicRenderer.tsx
"use client";

import { useEffect, useMemo, useState } from "react";

/* ============================ Types ============================ */
export type Pkg = {
  id: string;
  label: string;
  basePrice: number | null;
  description?: string;
  featured?: boolean;
  color?: string;
};

export type FeatureOption = {
  id: string;
  label: string;
  highlighted?: boolean;
  color?: string;
};

export type FeaturesGroup = {
  id: string;
  type: "features";
  title?: string;
  pkgId?: string;
  options: FeatureOption[];
  color?: string;
};

export type RangePricing =
  | { mode: "linear"; deltaPerUnit: number }
  | { mode: "per-step"; perStep: number[] };

export type RangeGroup = {
  id: string;
  type: "range";
  title?: string;
  min?: number;
  max?: number;
  step?: number;
  unit?: string;
  base?: number; // referentna vrednost za linear
  pricing?: RangePricing;
  color?: string;
};

export type Extra = {
  id: string;
  text: string;
  price?: number;
  selected?: boolean; // default selection (editor)
};

export type CalcView = {
  packages: Pkg[];
  fields: (FeaturesGroup | RangeGroup)[];
  addons: Extra[];
};

/* ========================= Type guards ========================= */
function isFeatures(g: any): g is FeaturesGroup {
  return g && g.type === "features" && Array.isArray(g.options);
}
function isRange(g: any): g is RangeGroup {
  return g && g.type === "range";
}

/* ============================ Component ============================ */
export default function PublicRenderer({ calc }: { calc: CalcView }) {
  // Stable lists
  const pkgs = Array.isArray(calc?.packages) ? calc.packages : [];
  const featureGroups: FeaturesGroup[] = useMemo(
    () => (Array.isArray(calc?.fields) ? calc.fields.filter(isFeatures) : []),
    [calc?.fields]
  );
  const rangeGroups: RangeGroup[] = useMemo(
    () => (Array.isArray(calc?.fields) ? calc.fields.filter(isRange) : []),
    [calc?.fields]
  );
  const extras = Array.isArray(calc?.addons) ? calc.addons : [];

  // Active package
  const [activePkgId, setActivePkgId] = useState<string | null>(pkgs[0]?.id ?? null);
  useEffect(() => {
    if (!activePkgId && pkgs[0]?.id) setActivePkgId(pkgs[0].id);
  }, [pkgs, activePkgId]);

  // Extras state (checkbox selection)
  const [extrasState, setExtrasState] = useState<Record<string, boolean>>(() =>
    Object.fromEntries(extras.map((x) => [x.id, !!x.selected]))
  );
  useEffect(() => {
    // re-sync defaults if addons list changes
    setExtrasState((prev) => {
      const next = { ...prev };
      extras.forEach((x) => {
        if (!(x.id in next)) next[x.id] = !!x.selected;
      });
      // drop removed ids
      Object.keys(next).forEach((id) => {
        if (!extras.some((x) => x.id === id)) delete (next as any)[id];
      });
      return next;
    });
  }, [extras]);

  // Slider values
  const initialSliderValues = useMemo(
    () => Object.fromEntries(rangeGroups.map((g) => [g.id, Number.isFinite(g.base) ? (g.base as number) : (g.min ?? 0)])),
    [rangeGroups]
  );
  const [sliderValues, setSliderValues] = useState<Record<string, number>>(initialSliderValues);
  useEffect(() => setSliderValues(initialSliderValues), [initialSliderValues]);

  // Active package data
  const activePkg = pkgs.find((p) => p.id === activePkgId) || null;
  const basePrice = typeof activePkg?.basePrice === "number" ? activePkg!.basePrice! : 0;

  // Features for active package
  const featuresForActive: FeatureOption[] = useMemo(() => {
    if (!activePkgId) return [];
    const g = featureGroups.find((f) => f.pkgId === activePkgId);
    return g?.options ?? [];
  }, [featureGroups, activePkgId]);

  // Extras total
  const extrasTotal = extras.reduce((sum, x) => {
    const picked = !!extrasState[x.id];
    const px = Number.isFinite(x.price) ? (x.price as number) : 0;
    return picked ? sum + px : sum;
  }, 0);

  // Slider delta
  function sliderDeltaFor(g: RangeGroup, value: number): number {
    const pricing = g.pricing?.mode ? g.pricing : ({ mode: "linear", deltaPerUnit: 0 } as RangePricing);
    const min = Number.isFinite(g.min) ? (g.min as number) : 0;
    const step = Number.isFinite(g.step) ? (g.step as number) : 1;
    if (pricing.mode === "linear") {
      const base = Number.isFinite(g.base) ? (g.base as number) : min;
      const dpu = (pricing as any).deltaPerUnit ?? 0;
      return (value - base) * dpu;
    } else {
      // per-step
      const arr = Array.isArray((pricing as any).perStep) ? (pricing as any).perStep as number[] : [];
      const idx = Math.max(0, Math.min(arr.length - 1, Math.floor((value - min) / Math.max(1, step))));
      return arr[idx] ?? 0;
    }
  }
  const slidersDelta = rangeGroups.reduce((sum, g) => {
    const v = sliderValues[g.id] ?? (Number.isFinite(g.base) ? (g.base as number) : (g.min ?? 0));
    return sum + sliderDeltaFor(g, v);
  }, 0);

  const total = basePrice + extrasTotal + slidersDelta;

  /* ============================ UI ============================ */
  return (
    <div className="space-y-10">
      {/* Packages */}
      <section>
        <h2 className="text-lg font-medium">Packages</h2>
        {pkgs.length === 0 ? (
          <p className="mt-2 text-sm opacity-70">No packages configured.</p>
        ) : (
          <div className="mt-3 grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {pkgs.map((p) => {
              const isActive = p.id === activePkgId;
              return (
                <div
                  key={p.id}
                  className={`rounded-xl border p-4 transition ${
                    isActive
                      ? "outline outline-1 outline-[var(--brand-1,#4F46E5)]"
                      : "hover:border-[color-mix(in_oklab,var(--brand-1,#4F46E5)_40%,transparent)]"
                  }`}
                  style={{ borderColor: p.color || undefined }}
                >
                  <div className="flex items-baseline justify-between">
                    <div className="font-medium">{p.label}</div>
                    <div className="text-sm opacity-70">
                      {p.basePrice == null ? "Custom" : `€${p.basePrice}`}
                    </div>
                  </div>
                  {p.description && (
                    <p className="mt-1 text-sm opacity-70 whitespace-pre-line">{p.description}</p>
                  )}
                  <div className="mt-3">
                    <button
                      type="button"
                      className={`rounded-lg border px-3 py-1.5 text-sm ${isActive ? "bg-white/5" : ""}`}
                      onClick={() => setActivePkgId(p.id)}
                    >
                      {isActive ? "Selected" : "Select"}
                    </button>
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </section>

      {/* Features (only for active package) */}
      {activePkgId && (
        <section>
          <h2 className="text-lg font-medium">Features</h2>
          {featuresForActive.length === 0 ? (
            <p className="mt-2 text-sm opacity-70">No features for this package.</p>
          ) : (
            <ul className="mt-2 space-y-1 text-sm">
              {featuresForActive.map((f) => (
                <li key={f.id} className="flex items-center justify-between">
                  <span className="inline-flex items-center gap-2">
                    <span
                      className="h-2 w-2 rounded-full"
                      style={{ backgroundColor: f.color || activePkg?.color || undefined }}
                    />
                    {f.label}
                  </span>
                  {f.highlighted && (
                    <span className="rounded px-2 py-0.5 text-2xs"
                          style={{
                            border: `1px solid ${f.color || activePkg?.color || "var(--brand-1,#4F46E5)"}`,
                            color: f.color || activePkg?.color || undefined
                          }}>
                      highlighted
                    </span>
                  )}
                </li>
              ))}
            </ul>
          )}
        </section>
      )}

      {/* Extras (global) */}
      <section>
        <h2 className="text-lg font-medium">Extras</h2>
        {extras.length === 0 ? (
          <p className="mt-2 text-sm opacity-70">No extras.</p>
        ) : (
          <div className="mt-2 space-y-2">
            {extras.map((x) => {
              const checked = !!extrasState[x.id];
              return (
                <label key={x.id} className="flex items-center justify-between rounded-xl border p-3 text-sm">
                  <span className="inline-flex items-center gap-2">
                    <input
                      type="checkbox"
                      className="h-4 w-4"
                      checked={checked}
                      onChange={(e) =>
                        setExtrasState((s) => ({ ...s, [x.id]: e.target.checked }))
                      }
                    />
                    <span>{x.text}</span>
                  </span>
                  <span className={`ml-4 ${checked ? "opacity-100" : "opacity-60"}`}>
                    €{Number(x.price ?? 0)}
                  </span>
                </label>
              );
            })}
          </div>
        )}
      </section>

      {/* Sliders (global) */}
      {rangeGroups.length > 0 && (
        <section>
          <h2 className="text-lg font-medium">Sliders</h2>
          <div className="mt-3 space-y-4">
            {rangeGroups.map((g) => {
              const min = Number.isFinite(g.min) ? (g.min as number) : 0;
              const max = Number.isFinite(g.max) ? (g.max as number) : 10;
              const step = Number.isFinite(g.step) ? (g.step as number) : 1;
              const unit = g.unit ?? "";
              const val = sliderValues[g.id] ?? (Number.isFinite(g.base) ? (g.base as number) : min);
              const delta = sliderDeltaFor(g, val);
              return (
                <div key={g.id} className="rounded-xl border p-4" style={{ borderColor: g.color || undefined }}>
                  <div className="mb-2 flex items-center justify-between">
                    <div className="font-medium">{g.title ?? "Range"}</div>
                    <div className="text-sm opacity-70">Δ {delta >= 0 ? `+€${delta}` : `€${delta}`}</div>
                  </div>
                  <div className="flex items-center gap-3">
                    <input
                      type="range"
                      min={min}
                      max={max}
                      step={step}
                      value={val}
                      onChange={(e) =>
                        setSliderValues((s) => ({ ...s, [g.id]: Number(e.target.value) }))
                      }
                      className="flex-1"
                    />
                    <div className="w-28 text-right text-sm">
                      {val}{unit ? ` ${unit}` : ""}
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </section>
      )}

      {/* Summary */}
      <section className="rounded-xl border p-4">
        <div className="flex items-baseline justify-between">
          <div className="text-lg font-medium">Total</div>
          <div className="text-xl font-semibold">
            €{total}
          </div>
        </div>
        <div className="mt-1 text-xs opacity-70">
          base €{basePrice} + extras €{extrasTotal} + sliders €{slidersDelta}
        </div>
      </section>
    </div>
  );
}
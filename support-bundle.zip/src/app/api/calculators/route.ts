import { NextResponse } from "next/server";
import { getUserIdFromRequest } from "../../../lib/auth";
import path from "path";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// mora da match-uje logiku iz calcsStore.ts
function safeUserId(userId: string) {
  return (userId || "anon")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 120) || "anon";
}
function debugFile(userId: string) {
  const uid = safeUserId(userId);
  return path.join(process.cwd(), "data", "users", uid, "calculators.json");
}

export async function GET(req: Request) {
  const userId = getUserIdFromRequest(req);
  try {
    const db = await import("../../../lib/calcsStore");
    const rows = await db.list(userId);
    return NextResponse.json({ rows, __debug: { userId, file: debugFile(userId) } });
  } catch (e: any) {
    console.error("LIST /api/calculators failed:", e);
    return NextResponse.json({ error: "list_failed", detail: e?.stack ?? String(e) }, { status: 500 });
  }
}

export async function POST(req: Request) {
  const userId = getUserIdFromRequest(req);
  try {
    const body = await req.json().catch(() => ({} as any));
    const db = await import("../../../lib/calcsStore");

    if (body?.from && body?.name) {
      const slug = await db.duplicate(userId, body.from, body.name);
      if (!slug) return NextResponse.json({ error: "not_found" }, { status: 404 });
      return NextResponse.json({ slug, __debug: { userId, file: debugFile(userId) } });
    }

    const name = (body?.name ?? "Untitled Page") as string;
    const row = await db.create(userId, name);
    return NextResponse.json({ slug: row.meta.slug, __debug: { userId, file: debugFile(userId) } });
  } catch (e: any) {
    console.error("CREATE /api/calculators failed:", e);
    return NextResponse.json({ error: "create_failed", detail: e?.stack ?? String(e) }, { status: 500 });
  }
}
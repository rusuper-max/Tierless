// src/app/p/[slug]/page.tsx
import { notFound } from "next/navigation";
import PublicRenderer from "../../../components/PublicRenderer";
import { calcFromMetaConfig } from "../../../lib/calc-init";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

// --- helpers (lokalni, bez aliasa i bez dodatnih fajlova) ---
async function getFull(ownerId: string, slug: string) {
  const fs = await import("fs/promises");
  const path = await import("path");
  const safe = ownerId
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "_")
    .replace(/_+/g, "_")
    .replace(/^_+|_+$/g, "")
    .slice(0, 120) || "anon";
  const file = path.join(process.cwd(), "data", "users", safe, "full", `${slug}.json`);
  try { return JSON.parse(await fs.readFile(file, "utf8")); } catch { return undefined; }
}

async function findFullBySlug(slug: string) {
  const fs = await import("fs/promises");
  const path = await import("path");
  const root = path.join(process.cwd(), "data", "users");
  let dirs: import("fs").Dirent[] = [];
  try { dirs = await fs.readdir(root, { withFileTypes: true }) as any; } catch { return undefined; }
  for (const d of dirs) {
    if (!(d as any).isDirectory?.()) continue;
    const file = path.join(root, (d as any).name, "full", `${slug}.json`);
    try { return JSON.parse(await fs.readFile(file, "utf8")); } catch {}
  }
  return undefined;
}

async function findMiniBySlug(slug: string) {
  const fs = await import("fs/promises");
  const path = await import("path");
  const root = path.join(process.cwd(), "data", "users");
  let dirs: import("fs").Dirent[] = [];
  try { dirs = await fs.readdir(root, { withFileTypes: true }) as any; } catch { return undefined; }
  for (const d of dirs) {
    if (!(d as any).isDirectory?.()) continue;
    const file = path.join(root, (d as any).name, "calculators.json");
    try {
      const txt = await fs.readFile(file, "utf8");
      const arr = JSON.parse(txt);
      if (Array.isArray(arr)) {
        const row = arr.find((r: any) => r?.meta?.slug === slug);
        if (row) return row;
      }
    } catch {}
  }
  return undefined;
}

// --- page ---
export default async function PublicPage({
  params,
  searchParams,
}: {
  params: { slug: string };
  searchParams?: { u?: string };
}) {
  const slug = params.slug;
  const owner = searchParams?.u; // npr. "dev:ru@example.com"

  let data: any = null;

  // 1) ako znamo ownera, probaj direktno njegov FULL
  if (owner) {
    data = await getFull(owner, slug);
    if (data) return (
      <main data-theme="tierless">
        <PublicRenderer data={{ ...data, meta: { ...data.meta, slug } }} />
      </main>
    );
  }

  // 2) globalni FULL (ako nema u=)
  data = await findFullBySlug(slug);

  // 3) fallback: MINI seed (ako FULL ne postoji)
  if (!data) {
    const mini = await findMiniBySlug(slug);
    if (mini) data = calcFromMetaConfig(mini);
  }

  if (!data) notFound();

  return (
    <main data-theme="tierless">
      <PublicRenderer data={{ ...data, meta: { ...data.meta, slug } }} />
    </main>
  );
}
import fs from "fs/promises";
import path from "path";

const PUB_ROOT = path.join(process.cwd(), "data", "public");
const fileFor = (slug: string) => path.join(PUB_ROOT, `${slug}.json`);
const indexFile = () => path.join(PUB_ROOT, "index.json");

export async function getPublic(slug: string) {
  try {
    const txt = await fs.readFile(fileFor(slug), "utf8");
    return JSON.parse(txt);
  } catch {
    return undefined;
  }
}

/** Upisuje javnu kopiju kalkulatora (SSR-friendly). */
export async function putPublic(slug: string, data: any, ownerId: string) {
  await fs.mkdir(PUB_ROOT, { recursive: true });
  // sigurnosno: ne zapisuj undefined/null
  const payload = data ?? {};
  await fs.writeFile(fileFor(slug), JSON.stringify(payload, null, 2), "utf8").catch(() => {});

  // održavaj mali indeks (nije obavezno, ali korisno za debug)
  let idx: Record<string, any> = {};
  try {
    const t = await fs.readFile(indexFile(), "utf8");
    idx = JSON.parse(t) || {};
  } catch {}
  idx[slug] = { owner: ownerId, updated: Date.now() };
  await fs.writeFile(indexFile(), JSON.stringify(idx, null, 2), "utf8").catch(() => {});
}
import type { NextConfig } from "next";
const nextConfig: NextConfig = {
  transpilePackages: ["iron-session"],
};
export default nextConfig;
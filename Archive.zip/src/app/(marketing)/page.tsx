// src/app/(marketing)/page.tsx
import "@/styles/marketing.css";
import MainPhase1 from "@/components/scrolly/MainPhase1";
import MainPhase2 from "@/components/scrolly/MainPhase2";
import MainPhase3 from "@/components/scrolly/MainPhase3";
import Phase1Snap from "@/components/scrolly/Phase1Snap";
import Phase2Snap from "@/components/scrolly/Phase2Snap";
import Phase3Overlap from "@/components/scrolly/Phase3Overlap";

export const metadata = {
  title: "Tierless — Pricing pages made simple",
  description: "Create a price page without a website. Share, configure, receive structured inquiries.",
};

export default function Page() {
  return (
    <>
      {/* P1 */}
      <MainPhase1 />

      {/* P1 → P2 snap (radi ti super već) */}
      <Phase1Snap
        prevRefSelector={`section[aria-label="Hero Phase"]`}
        targetSelector={`#phase2`}
        duration={0.6}
      />

      {/* P2 */}
      <section id="phase2" className="relative z-10">
        <MainPhase2
          headline="Create your price page for any business"
          holdDesktop={0.22}  // ~malo duži solo hold naslova
          holdMobile={0.14}
        />
      </section>

      {/* P2 → P3 snap (isti princip kao P1→P2) */}
      <Phase2Snap
        prevRefSelector={`#phase2 section[aria-label="Scroll storytelling pricing intro"]`}
        targetSelector={`#phase3`}
        gate={0.995}
        duration={0.6}
      />

      {/* Blag overlap da ubijemo vizuelni gap (počni sa -120, doteži po ukusu) */}
      <Phase3Overlap
        prevRefSelector={`#phase2 section[aria-label="Scroll storytelling pricing intro"]`}
        overlapPx={-120}
      >
        <section id="phase3" className="relative z-10">
          <MainPhase3 />
        </section>
      </Phase3Overlap>
    </>
  );
}
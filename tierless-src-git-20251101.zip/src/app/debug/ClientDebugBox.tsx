// src/app/debug/ClientDebugBox.tsx
"use client";

import { useEffect, useState } from "react";

export default function ClientDebugBox() {
  const [status, setStatus] = useState<any>(null);
  const [email, setEmail] = useState("test@dev.local");
  const [cookiesStr, setCookiesStr] = useState("");

  async function checkStatus() {
    const r = await fetch("/api/auth/status", {
      credentials: "include",
      cache: "no-store",
    });
    const j = await r.json().catch(() => null);
    setStatus(j);
    setCookiesStr(document.cookie || "");
  }

  async function devLogin() {
    await fetch("/api/dev-login", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ email }),
    });
    await checkStatus();
    // obavesti navbar da refetchuje /api/auth/status
    window.dispatchEvent(new Event("TL_AUTH_CHANGED"));
  }

  async function devLogout() {
    await fetch("/api/dev-logout", { method: "POST" });
    await checkStatus();
    window.dispatchEvent(new Event("TL_AUTH_CHANGED"));
  }

  useEffect(() => {
    checkStatus();
  }, []);

  return (
    <section style={{ marginTop: 24 }}>
      <h2 style={{ fontSize: 18, marginBottom: 8 }}>Client checks</h2>

      <div style={{ display: "flex", gap: 8, marginBottom: 12 }}>
        <input
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="email"
          style={{
            padding: "8px 10px",
            border: "1px solid #cbd5e1",
            borderRadius: 8,
            minWidth: 260,
          }}
        />
        <button onClick={devLogin} style={btnStyle}>
          Dev Login
        </button>
        <button onClick={devLogout} style={btnStyle}>
          Dev Logout
        </button>
        <button onClick={checkStatus} style={btnStyle}>
          Check /api/auth/status
        </button>
      </div>

      <p style={{ opacity: 0.8 }}>Client status (CSR):</p>
      <pre style={preStyle}>{JSON.stringify(status, null, 2)}</pre>

      <p style={{ opacity: 0.8 }}>document.cookie:</p>
      <pre style={preStyle}>{cookiesStr || "(empty)"}</pre>
    </section>
  );
}

const btnStyle: React.CSSProperties = {
  padding: "8px 12px",
  border: "1px solid #22d3ee",
  borderRadius: 8,
  background: "#06141d",
  color: "#e6fbff",
  cursor: "pointer",
};

const preStyle: React.CSSProperties = {
  background: "#0b1220",
  color: "#cfe9ff",
  padding: 12,
  borderRadius: 8,
  overflow: "auto",
};